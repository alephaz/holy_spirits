@extends('layouts.app')

@section('title', 'Welcome to HolySpirit')

@section('content')

    events show page

@endsection