@extends('layouts.app')

@section('title', 'Donations')

@section('content')
    <div class="inner-page">
        <h1 class="text-blue">Donations</h1>
    </div>

@endsection